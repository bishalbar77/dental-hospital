    <!-- ! Main nav -->
    <nav class="main-nav--bg">
        <div class="container main-nav">
          <div class="main-nav-start">
            <h4 style="font-weight: 600;color:#797979;">Welcome to your dashboard</h4>
          </div>
          <div class="main-nav-end">
            <button class="sidebar-toggle transparent-btn" title="Menu" type="button">
              <span class="sr-only">Toggle menu</span>
              <span class="icon menu-toggle--gray" aria-hidden="true"></span>
            </button>
            
            <div class="nav-user-wrapper" style="float: right;">
              <a href="<?php echo e(route('logout')); ?>" class="nav-user-btn dropdown-btn" title="Logout" type="button" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                <span class="sr-only">Logout</span>
                <span class="nav-user-img">
                  <picture><source srcset="../../img/avatar/log.png" type="image/webp"><img src="../../img/avatar/log.png" alt="User name"></picture>
                </span>
                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                  <?php echo csrf_field(); ?>
              </form>
              </a>
            </div>
            <div class="nav-user-wrapper" style="float: right;">
              <ul class="users-item-dropdown nav-user-dropdown dropdown">
                <li><a class="danger" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                    <i data-feather="log-out" aria-hidden="true"></i>
                    <span><?php echo e(__('Logout')); ?></span>
                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                        <?php echo csrf_field(); ?>
                    </form>
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>
    </nav><?php /**PATH D:\ProFoo\narayanidentalskincentere\resources\views/layouts/navbar.blade.php ENDPATH**/ ?>