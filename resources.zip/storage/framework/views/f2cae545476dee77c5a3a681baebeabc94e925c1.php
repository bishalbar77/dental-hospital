

<?php $__env->startSection('content'); ?>

    
    <section id="contact" class="contact">
      <div class="container">
          <div class="mb-3">
          <?php if(session()->has('message')): ?>
              <div class="alert alert-success">
                  <?php echo e(session()->get('message')); ?>

              </div>
          <?php elseif(session()->has('error')): ?>
              <div class="alert alert-danger">
                  <?php echo e(session()->get('message')); ?>

              </div>
          <?php endif; ?>
          </div>
      </div>
    </section>
    <section id="contact" class="contact">
      <div class="container">
          <h2 class="main-title" style="font-weight: 500;">&nbsp;</h2>

        <div class="section-title" data-aos="fade-up">
        </div>

        <div class="row">
          <div class="col-lg-12 mt-5 mt-lg-0 d-flex align-items-stretch">
            <form action="#" method="POST" enctype="multipart/form-data" class="php-email-form" style="border-radius: 10px; !important">
              
                      <!-- Repeater Heading -->
                <div class="row">
                  <div class="repeater-heading">
                      <h5 class="pull-left pt-3 pb-3">All Appointments</h5>
                  </div>
              </div>
              <table class="table table-bordered" width="100%" id="example">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Date</th>
                        <th>Time</th>
                        <th>Category</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $application; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $app): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td><?php echo e($app->user->name); ?></td>
                      <td><?php echo e($app->date); ?></td>
                      <td><?php echo e($app->time); ?></td>
                      <td><span class="badge-active"><?php echo e((($app->category == 'skin') ? 'Skin Care' : 'Dental Care')); ?></td>
                      <td><span class="badge-<?php echo e((($app->status == '0') ? 'active' : 'pending')); ?>"><?php echo e((($app->status == '0') ? 'Active' : 'Cancelled')); ?></span></td>
                      <td>
                        <?php if($app->status == '0'): ?>
                          <a type="button" class="btn btn-danger" href="/update-ppointment/<?php echo e($app->id); ?>">
                            <i class="fa fa-trash" aria-hidden="true"></i>
                          </a>
                        <?php else: ?>
                        
                        <?php endif; ?>
                      </td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            </form>
          </div>
        </div>
      </div>
  </section>
  <div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLongTitle">Modal title</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          ...
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="button" class="btn btn-primary">Save changes</button>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
       $(document).ready(function() {
          $('#example').DataTable();
      } );
      
    </script>
        <script src="https://cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js"></script>
        <script src="https://cdn.datatables.net/1.10.25/js/dataTables.bootstrap4.min.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\ProFoo\narayanidentalskincentere\resources\views/pages/my-applications.blade.php ENDPATH**/ ?>